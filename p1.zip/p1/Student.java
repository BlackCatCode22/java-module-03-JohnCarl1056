package p1;

public class Student {
    public String firstName;
    public String lastName;
    public double gpa;
    public String major;
    public int age;
    public boolean onProbation;

}
