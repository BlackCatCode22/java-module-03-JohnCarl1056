package p1;

public class BackPack {
    public String color;
    public String size;
    public String brand;
    public int zippers;
}
