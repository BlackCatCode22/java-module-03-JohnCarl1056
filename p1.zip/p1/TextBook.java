package p1;

public class TextBook {
    public String bookName;
    public int pageNumbers;
    public String Author;
    public String Genre;
}
